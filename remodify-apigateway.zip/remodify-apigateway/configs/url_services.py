
# Microservicios URLs
MICROSERVICE_BUSINESS = "https://zealous-joy-production.up.railway.app/api/v1/businesses"
MICROSERVICE_IAM = "https://renewed-radiance-production.up.railway.app/api/v1"
MICROSERVICE_PROJECT = "https://heartfelt-insight-production.up.railway.app/api/v1/projects"
MICROSERVICE_REVIEWS = "https://caring-joy-production.up.railway.app/api/v1/reviews"
MICROSERVICE_PROJECTREQUEST = "https://inspiring-consideration-production.up.railway.app/api/v1/project-requests"

