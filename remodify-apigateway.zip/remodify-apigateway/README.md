# Remodify API Gateway

## Installations
 - Poetry

## Execution
``` bash
poetry install
```

to run the project in development mode use:

``` bash
poetry run fastapi dev --port 8080 main.py
```